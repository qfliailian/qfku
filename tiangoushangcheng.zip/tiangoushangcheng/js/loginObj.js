// 登录注册对象
$(function() {
	loginObj.init();
	
})
var loginObj = {
	dom:{},
	init:function()　{
		this.domEvent();
	},
	domEvent:function() {
		var dom = this.dom;
		//新用户注册事件
		dom.newPeople = $('div.loginL>dl');
		//邮箱验证
		var reg1 = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
		// 用户名验证4-20英文字符，数字，‘_’的组合
		var reg2 = /^\w{4,20}$/;
		// 密码验证6-16位字符
		var reg3 = /^[A-Z|a-z|0-9]{6,16}$/;
	
       function math(){
       		var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678'; 
       		var $string = ''; 
       		var len = $chars.length;
       		for(i=0 ;i<4 ; i++){

				$string += $chars.charAt(parseInt(Math.random()*len));
       		}
       		return $string;
       }
       $('.loginL b.b_check').text(math());
       $('.loginL b.b_check').click(function() {
								// 点击一次产生随机数
								$(this).text(math());
						});

		dom.flag = true;
		$('.loginAll').find('input').val('');
		dom.newPeople.find('input').focus(function() {
			var name = $(this).attr('name');
			var next = $(this).next();
			
				switch(name) {
					case 'txtEmail' :next.text('请填写正确的邮箱');
							next.css('color','#070707');
							$(this).blur(function() {
									if(!reg1.test($(this).val()))
									{
										next.text('填写的邮箱不正确');
										next.css('color','red');
										dom.flag = false;
									}else{
										next.css('color','#070707');
										dom.flag = true;
									}
							})
							break;
					case 'txtName':next.text('4-20英文字符，数字，‘_’的组合');
									next.css('color','#070707');
							$(this).blur(function() {
									if(!reg2.test($(this).val()))
									{
										next.text('填写的名字不正确');
										next.css('color','red');
										dom.flag = false;
									}else {
										dom.flag = true;
									}
							})
							break;
					case 'txtPassword':next.text('6-16位字符');
									next.css('color','#070707');
							$(this).blur(function() {
									if(!reg3.test($(this).val()))
									{
										next.text('填写的密码不正确');
										next.css('color','red');
										dom.flag = false;
									}else {
										dom.flag = true;
									}
							})
							break;
					case 'checkPassword':next.text('二次密码必须一致');
									next.css('color','#070707');
							$(this).blur(function() {
									if($(this).val() != $('input[name=txtPassword]').val())
									{
										next.text('二个密码不一致');
										next.css('color','red');
										dom.flag = false;
									}else {
										dom.flag = true;
									}
							})
							break;
					case 'check':
							
							$(this).blur(function() {
								if($(this).val() != next.text()) {
									$(this).css('border-color','red');
									dom.flag = false;
								}else {
									$(this).css('border-color','#cfdce5');
									dom.flag = true;
								}
							});
					
				}

			
		});
		
		dom.name ='';
		dom.name = getCookie('name');
		
		$('input[name=newsubmit]').click(function() {
			var txtName = $('input[name=txtName]').val();
			if(txtName == dom.name){
				dom.flag = false;
				alert('用户名已经注册过！');
			}else {
				dom.flag = true;
			}
			
			if	(dom.flag==false || $('.loginL input[type=text]').val() == '') {
				alert('填写信息错误！');return;
			} else{
				//全部填写正确执行下面操作
				var newname = $('input[name=txtName]').val();
				setCookie1('name',newname,7);
				location.href ='success.html';
			}
		});
		//老用户登录
		$('.loginR input[name=xinsubmit]').click(function() {
			if($('.loginR input[name=agoName]').val() == dom.name && $('.loginR input[name=agoPws]').val() != ''  ) {
				location.href ='success.html';
			} else {
				alert('登录失败！');
			}
		})

		//左右两边的keydown事件
		var newsubmit = $('input[name=newsubmit]');
        var xinsubmit = $('input[name=xinsubmit]');
         $(window).keydown(function(e){
                e = e || event;
                var code = e.keyCode || e.which;
               if(code == 13 && $('.loginR input[type=text]').val() == '') {
                    newsubmit.click();
               }else if(code == 13 && $('.loginL input[type=text]').val() == '') {
               		xinsubmit.click();
               }
            });
	},
}