$(function(){
	obj.init();
})
// 主页面对象
var obj = {
	dom:{},
	init:function() {
		this.domInit();
		this.domEvent();
	},
	domInit:function() {
		this.dom.datu= $('#picD');
		this.dom.span = $('#pic .box span');
		this.dom.index = 0;//下标
	},
	domEvent:function() {
		var dom = this.dom;
		// 左边栏效果
		function fun1(){

				if ($('.sidebar_L').length != 0) {

					dom.scrollTop = $('.sidebar_L').offset().top;
					if(dom.scrollTop >1200 ) {
						$('.sidebar_L').animate({left:0,opacity:1},100);
					}else  {
						$('.sidebar_L').animate({left:'-60px',opacity:0},100);
					}
			
				}
				
		}
		dom.timer = setInterval(fun1,600);
	
		//右边栏效果
		$('.sb_item').hover(function() {
			$(this).find('div:not(.fix)').animate({left:'-103px',opacity:1});
			$(this).find('.item_tip').css('display','block');
			$(this).find('.fix').animate({left:'-370px',opacity:1});

		},function() {
			$(this).find('.item_tip').css('display','none');
			$(this).find('div:not(.fix)').animate({left:'-108px',opacity:0});
			$(this).find('.fix').animate({left:'-375px'});
		})
		
		//返回顶部
		$('span.go_top').click(function() {
			$('html,body').animate({scrollTop:0},500);
		})
		//动画封装函数
		function dongHuashow(obje,target,a) {
				var index = 0;
				if (obje.attr('id') == 'picD') {
					index =  a;
				}
				obje.timer = setInterval(function(){
					index++;
					if(index>target-1){ index=0;}
					obje.find('a').eq(index).siblings().animate({'opacity':0},1000);
					obje.find('a').eq(index).animate({'opacity':1},1000);
					//大图点亮效果
					if (obje.attr('id') == 'picD') {
						dom.span.css('background','#fff');
						dom.span.eq(index).css('background','red');
					}
				},2000);
		
		};



		//大图轮播事件
		var datu_len = dom.datu.find('a').length;
		dongHuashow(dom.datu,datu_len,0);

		dom.span.hover(function(){
			clearInterval(dom.datu.timer)
 			var index = $(this).index();
 			if (index > datu_len - 1) { 
 				index = 0;
 			}

			dom.datu.find('a').eq(index).siblings().stop().animate({'opacity':0},1000);
			dom.datu.find('a').eq(index).stop().animate({'opacity':1},1000);
			dom.span.css('background','#fff');
			dom.span.eq(index).css('background','red');
		}, function() {
			var index = $(this).index();
			dongHuashow(dom.datu,datu_len,index);
		})
	

		//数码图
		dom.shuma = $('#shumaD');
		var shu_len = dom.shuma.find('a').length;
		dongHuashow(dom.shuma,shu_len);

		//箱包图
		dom.xiangbao = $('#xiangbaoD');
		var len = dom.xiangbao.find('a').length;
		dongHuashow(dom.xiangbao,len);

		//厨具
		dom.chuju = $('#chujuD');
		var chuju_len = dom.chuju.find('a').length;
		dongHuashow(dom.chuju,chuju_len);
		//电脑办公
		dom.dianao = $('#dianaoD')
		var dianao_len = dom.dianao.find('a').length;
		dongHuashow(dom.dianao,dianao_len);

		//鞋帽
		dom.xiemao = $('#xiemaoD');
		var xiemao_len = dom.xiemao.find('a').length;
		dongHuashow(dom.xiemao,xiemao_len);
		 //个人护理
		 dom.huli = $('#huliD');
		 var huli_len = dom.huli.find('a').length;
		 dongHuashow(dom.huli,huli_len);
		

		var successObj = getCookie('flag');console.log(getCookie('name'));
		//登录成功
		if(successObj=='true') {
			$('.hello_1').css('display','none');
            $('.hello_2').css('display','block');
		}else {
			$('.hello_1').css('display','block');
            $('.hello_2').css('display','none');
		}
		//点击退出切换首页的头部
        $('a.reback').click(function(){
            setCookie('flag',false,2);
           	$('.hello_1').css('display','block');
            $('.hello_2').css('display','none');
        });
	},

}







