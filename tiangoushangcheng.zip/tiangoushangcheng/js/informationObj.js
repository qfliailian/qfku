$(function() {
	informationObj.init();
})
//个人信息对象
var informationObj = {
	dom:{},
	init:function(){
		this.domEvent();
	},
	domEvent:function() {
		var dom = this.dom;
		dom.flag = true;
		$('.loginAll').find('input').val('');
		//邮箱验证
		var reg1 = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
		// 用户名验证4-20英文字符，数字，‘_’的组合
		var reg2 = /^\w{4,20}$/;
		//判断真实名字
		var reg4 = /^[\u2E80-\u9FFF]{2,4}$/
		//验证固定电话
		var reg5 = /^1\d{10}$/;
		//邮编
		var reg6 = /^\d{5}$/;
		$('input').blur(function() {
			var name = $(this).attr('name');
			var next = $(this).next();
			var txt = $(this).val();
			switch(name) {
				case 'txtName' :
								if(!reg2.test(txt)) {
									next.css('color','red');
									dom.flag = false;
								}else {
									next.text('');
									next.css('color','#070707');
									dom.flag = true;
								}
								break;
				case 'txtEmail' :
								if(!reg1.test(txt)) {
									next.text('请输入邮箱错误！');
									next.css('color','red');
									dom.flag = false;
								}else {
									next.text('');
									next.css('color','#070707');
									dom.flag = true;
								}
								break;
				case 'trueName':
								if(!reg4.test(txt)) {
									next.text('输入真实姓名错误!');
									next.css('color','red');
									dom.flag = false;
								}else {
									next.text('');
									next.css('color','#070707');
									dom.flag = true;
								}
								break;
				case 'phone':
							if(!reg5.test(txt)) {
									next.text('输入电话错误!');
									next.css('color','red');
									dom.flag = false;
								}else {
									next.text('');
									next.css('color','#070707');
									dom.flag = true;
								}
								break;
				case 'bianma':
							if(!reg6.test(txt)) {
									next.text('输入编码错误!');
									next.css('color','red');
									dom.false = false;
								}else {
									next.text('');
									next.css('color','#070707');
									dom.flag = true;
								}
								break;
			}
		})

		$('.loginAll input[name=sureSubmit]').click(function() {
			//全部填写正确才能执行
			if($('.infor_text input').val()!='' && dom.flag){
				alert('修改成功!');
				var name = $('.infor_text input[name=txtName]').val();
				setCookie1('name',name,7);
				location.href="success.html"; 
			}else {
				alert('修改失败！');
			}
		})

		//点击退出切换首页的头部
        $('a.reback_2').click(function(){
            setCookie1('flag',false,2);
        });

	},
}