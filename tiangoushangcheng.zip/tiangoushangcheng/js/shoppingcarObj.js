$(function() {
	shoppingcarObj.init();
	
})

//购物车对象
var shoppingcarObj = {
	dom:{},
	init:function() {
		this.domEvent();
	},
	domEvent:function() {
		var dom = this.dom;
		//购物数量
		dom.count  = 0;
		//商品总价格
		dom.money = 0;
		dom.zhehou = 0;
	
		//一开始打开页面的时候显示数量，单价，总数
		$('div.shcar_btm input[type=text]').each(function() {
			dom.count +=  parseInt($(this).val());
		});
		
		$('b.shcar_danjia').each(function() {
			var danjia = parseInt($(this).text().slice(1));
			var count = parseInt($(this).parent().next().find('input').val());
			var b = $(this).parent().next().next();
			b.find('b.shcar_money').text('￥'+danjia*count);
		})
		$('b.shcar_money').each(function() {
			dom.money += parseInt($(this).text().slice(1));
		})
		// 定时检查更新数量，商品总价
		dom.timer = setInterval(function() {
		
			$('span.shopping_Count').text(dom.count);
			$('span.shopping_money').text('￥'+dom.money);
			//商品折后价格
			dom.zhehou = dom.money*0.9;
			$('span.shopping_zhehou').text('￥'+dom.zhehou);

		},100)
		

	


		//减的数量变化
		$('em.em1').click(function() {
			var count = parseInt($(this).next().val());
			if(count==0){
				count = 0;
				return;
			}else {
				count --;
			}
			if(dom.count==0){
				dom.count==0;
				dom.money = 0;
			}else {
				
				dom.count--;
			}

			$(this).next().val(count);
			var danjia = $(this).parent().prev().find('b.shcar_danjia').text();
			danjia = parseInt(danjia.slice(1));
			$(this).parent().next().find('b.shcar_money').text('￥'+danjia*count);
			dom.money -= danjia;

		})
		// 加的数量变化
		$('em.em2').click(function() {
			var count = parseInt($(this).prev().val());
			count ++;
			dom.count ++;
			$(this).prev().val(count);
			var danjia = $(this).parent().prev().find('b.shcar_danjia').text();
			danjia = parseInt(danjia.slice(1));
			$(this).parent().next().find('b.shcar_money').text('￥'+danjia*count);

			dom.money += danjia;
		})

		//取消订单
		$('table tr a').click(function() {
			//点击删除tr
			var r = window.confirm('真的要删除这件商品吗？');
			if(r) {
					$(this).parent().parent().remove();
					var money = 0;
					$('b.shcar_money').each(function() {
						
						money += parseInt($(this).text().slice(1));
						dom.money = money;
					})
					var i = 0;
					$('table tr input[type=text]').each(function() {
									i +=  parseInt($(this).val());
							});
					dom.count = i;
				}
		})


		//清空购物车
		$('a.clear_All').click(function() {
			var r = window.confirm('真的要删除这件商品吗？');
			if(r) {
				$('table tr:not(.t_first)').remove();
				alert('您可以去继续购物看看！');
			}

		})
		//购物车完成之后才可以点击
		$('#jisu').click(function() {
			if(dom.zhehou != 0) {
				clearInterval(dom.timer);
				//把折后价存到cookie里面
				setCookie('count',dom.count,1);
				setCookie('money',dom.zhehou,1);
				$(this).attr('href','fillout.html');
				
			} else {
				alert('请选择购买的商品');
			}
			
		});

		//点击退出切换首页的头部
        $('a.reback_2').click(function(){
            setCookie1('flag',false,2);
        });
	},
}