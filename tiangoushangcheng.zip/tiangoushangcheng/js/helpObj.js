$(function() {
	helpObj.init();

})
// 帮助中心对象
var helpObj = {
	dom:{},
	init:function() {
		this.domEvent();
	},
	domEvent:function() {
		var dom = this.dom;

		var successObj = getCookie('flag');
		//登录成功
		if(successObj=='true') {
			$('.hello_1').css('display','none');
            $('.hello_2').css('display','block');
		}else {
			$('.hello_1').css('display','block');
            $('.hello_2').css('display','none');
		}
		//点击退出切换首页的头部
        $('a.reback').click(function(){
            setCookie1('flag',false,2);
           	$('.hello_1').css('display','block');
            $('.hello_2').css('display','none');
        });
		//获取点击事件a标签
		dom.helpL = $('div.help_midL');
		
		dom.helpR = $('div.help_midR');
	
		
		dom.helpL.find('a').click(function() {
				var txt = $(this).text();
				txt = txt.slice(1);
				dom.helpR.find('h3').text(txt);
				dom.helpR.find('.help_text').html();
		})
	},
}