$(function() {
	favoriteObj.init();
	
})
//我的收藏夹
var favoriteObj = {
	dom:{},
	init:function() {
		this.domEvent();
	},
	domEvent:function() {
		var dom = this.dom;
		$('tr.t_first input').click(function() {
				var flag =$(this).is(':checked');
				if(flag) {
					$('input[type=checkBox]').prop('checked',true);
				}else{
					$('input[type=checkBox]').prop('checked',false);
				}
		})

		//点击退出切换首页的头部
        $('a.reback_2').click(function(){
            setCookie1('flag',false,2);
        });

	},
}