$(function() {
	submitObj.init();
})
// 订单成功对象
var submitObj = {
	dom:{},
	init:function() {
		this.domEvent();
	},
	domEvent:function() {
		var dom = this.dom;
		//交易总金额
		var money = parseInt(getCookie('money'));
		var yunfei =parseInt($('i.yunfei').text());

		dom.zongjia = money+ yunfei;
		$('span.zongjia').text('￥'+dom.zongjia);

		//点击退出切换首页的头部
        $('a.reback_2').click(function(){
            setCookie1('flag',false,2);
        });

	},
}