$(function() {
	filloutObj.init()
	
})
//订单填写信息对象(没有验证)
var filloutObj = {
	dom:{},
	init:function() {
		this.domEvent();
	},
	domEvent:function() {
		var dom = this.dom;
		dom.flag = true;//标志

		// 页面一进来清空input、textarea的内容
		dom.input = $('div.fillout_mid input');
		dom.input.val('');
		dom.textarea = $('div.fillout_mid textarea' );
		dom.textarea.text('');

		//商品总数量和总金额
		var count = parseInt(getCookie('count'));
		var money = parseInt(getCookie('money'));
		$('span.count').text('￥' + count);
		$('span.money').text('￥' + money);

		var yunfei =parseInt($('i.yunfei').text());

		dom.zongjia = money+ yunfei;
		$('span.zongjia').text('￥'+dom.zongjia);
		// 点击头部切换样式
		dom.li = $('.fillout ul li');
		dom.li.click(function() {
			dom.li.removeClass('hover');
			$(this).addClass('hover');
			var index = $(this).index();
			$('div.fillout_mid').css('display','none');
			$('div.fillout_mid').eq(index).css('display','block');
		})


		$('#jisu1').click(function() {
			//如果全部填写正确，执行下列步骤
			if(dom.flag) {
				
				$(this).attr('href','submit.html');
				
			} else {
				alert('请填写完完整');
			}
		})

		//点击退出切换首页的头部
        $('a.reback_2').click(function(){
            setCookie1('flag',false,2);
        });

        // 常用地址点击事件
        $('a.changyong').click(function() {
        	$(this).prev().val('北京市市辖区海定区某某地方');
        })
	},
}