$(function() {
	successObj.init();
})
//登录成功对象
var successObj = {
	dom:{},
	init:function () {
		this.domEvent();
	},
	domEvent:function() {
		//登录成功获取用户名
		var dom = this.dom;
		setCookie1('flag',true,2);
		//点击退出切换首页的头部
        $('a.reback_2').click(function(){
            setCookie1('flag',false,2);
        });
	},

}